package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.ChambreView;
import view.ClientView;
import view.EmployeView;
import view.ReservationView;
import view.ServiceView;

public class MainView extends JFrame {

    private JPanel contentPanel;

    public MainView() {
        initialize();
    }

    private void initialize() {
        setTitle("Hotel Reservation Management");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
}}